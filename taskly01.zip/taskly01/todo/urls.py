from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name="" ),
    path ('my-login/', views.my_login, name="my-login"),
    path ('user-logout/', views.user_logout, name="user-logout"), 
    path ('register/', views.register, name="register"),
    path ('dashboard/', views.dashboard, name="dashboard"),
    #-------------CRUD-------------------------
    #-----------------CREATE-------------------
    path ('create-task/', views.createTask, name="create-task"), 
    #-----------Read-------------------
    path ('view-task/', views.viewTask, name="view-task"), 
    #-----------UPDATE-------------------
    path ('update-task/<str:pk>/', views.updateTask, name="update-task"), 
    #-----------DELETE-------------------
    path ('delete-task/<str:pk>/', views.deleteTask, name="delete-task"), 
    #-----------profile management-------------------
    path ('profile-management/', views.profile_management, name="profile-management"), 
  #-----------profile Delete Account-------------------
    path ('delete-account/', views.deleteAccount, name="delete-account"), 
  
  
  
  
    
]